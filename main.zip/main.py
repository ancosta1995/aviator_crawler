import logging
import random
from datetime import datetime, timedelta
import pytz
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import Application
import asyncio

# ==========================
# CONFIGURAÇÕES (edite aqui)
# ==========================
BOT_TOKEN = "8278668067:AAH8w3sRxThCSrG9Ftrz1h7tZZ5CgDfooaA"
CHAT_ID = -1001766959534  # grupo/supergrupo começa com -100; para usuário, use ID positivo

# Fuso horário
TIMEZONE = pytz.timezone("America/Sao_Paulo")

# Intervalos
CICLO_ENVIO = 30        # segundos entre mensagens
INICIO_OFFSET = 30      # 1º horário começa +30s do envio
QTD_HORARIOS = 3        # quantidade de relógios
INTERVALO_MIN = 60      # intervalo mínimo entre relógios (s)
INTERVALO_MAX = 120     # intervalo máximo entre relógios (s)

# Tempo para editar a mensagem com estatísticas
TEMPO_EDICAO = 30       # segundos

# Botão
BOTAO_TEXTO = "CLIQUE AQUI E SE CADASTRE"
BOTAO_URL = "http://www.cassinopro.bet"

# ==========================
# LOGS
# ==========================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ==========================
# VARIÁVEIS GLOBAIS
# ==========================
bot_data = {}  # message_id -> texto original
app = None
scheduler = None

# ==========================
# FUNÇÕES
# ==========================
def gerar_horarios():
    base = datetime.now(TIMEZONE) + timedelta(seconds=INICIO_OFFSET)
    horarios = []
    atual = base
    for _ in range(QTD_HORARIOS):
        # sem segundos
        horarios.append(atual.strftime("%H:%M"))
        atual += timedelta(seconds=random.randint(INTERVALO_MIN, INTERVALO_MAX))
    return horarios

def montar_mensagem():
    horarios = gerar_horarios()
    relogios = "\n".join(["⏰ " + h for h in horarios])
    mensagem = f"""✈ LISTA PROBABILIDADE AVIATOR 

💳 Segurança em 2x 💳
✈ Buscar 4.00x a 50x 

{relogios}

⚠ Entrar 15s antes ou no horário exato! 
🔞 Proibido para menores idade
"""
    return mensagem.strip(), len(horarios)

async def enviar_mensagem():
    global app
    try:
        if app is None:
            logger.error("App não inicializado!")
            return
            
        mensagem, qtd = montar_mensagem()
        teclado = InlineKeyboardMarkup([[InlineKeyboardButton(BOTAO_TEXTO, url=BOTAO_URL)]])

        msg = await app.bot.send_message(
            chat_id=CHAT_ID,
            text=mensagem,
            parse_mode=ParseMode.HTML,
            reply_markup=teclado
        )
        bot_data[msg.message_id] = mensagem
        logger.info(f"Mensagem enviada: {msg.message_id}")

        # agenda a edição dessa mensagem
        scheduler.add_job(
            editar_mensagem,
            "date",
            run_date=datetime.now(TIMEZONE) + timedelta(seconds=TEMPO_EDICAO),
            args=[msg.message_id, qtd],
            id=f"edit_{msg.message_id}"  # ID único para evitar conflitos
        )
    except Exception as e:
        logger.exception(f"Falha ao enviar mensagem: {e}")

async def editar_mensagem(message_id: int, qtd: int):
    global app
    try:
        if app is None:
            logger.error("App não inicializado!")
            return
            
        texto_extra = f"\n\n✅ Vitorias: {qtd} (100%)\n❌ Derrotas: 0 (0.00%)"
        teclado = InlineKeyboardMarkup([[InlineKeyboardButton(BOTAO_TEXTO, url=BOTAO_URL)]])

        original = bot_data.get(message_id, "")
        await app.bot.edit_message_text(
            chat_id=CHAT_ID,
            message_id=message_id,
            text=f"{original}{texto_extra}",
            parse_mode=ParseMode.HTML,
            reply_markup=teclado
        )
        logger.info(f"Mensagem {message_id} editada com estatísticas.")
        
        # Remove da memória após editar
        if message_id in bot_data:
            del bot_data[message_id]
            
    except Exception as e:
        logger.exception(f"Falha ao editar mensagem {message_id}: {e}")

async def inicializar_bot():
    global app, scheduler
    
    # Cria a aplicação
    app = Application.builder().token(BOT_TOKEN).build()
    await app.initialize()
    await app.start()
    
    # Configura o scheduler
    scheduler = AsyncIOScheduler(timezone=TIMEZONE)
    scheduler.start()
    
    # Agenda envio periódico
    scheduler.add_job(
        enviar_mensagem,
        "interval",
        seconds=CICLO_ENVIO,
        next_run_time=datetime.now(TIMEZONE) + timedelta(seconds=5),  # 1ª execução em 5s
        coalesce=True,
        max_instances=1,
        id="envio_periodico"
    )
    
    logger.info("Bot inicializado e scheduler configurado!")
    
    # Envio imediato de teste
    #logger.info("Enviando mensagem de teste imediata...")
    #await enviar_mensagem()

async def manter_bot_ativo():
    """Mantém o bot rodando indefinidamente"""
    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        logger.info("Recebido sinal de interrupção...")
    except Exception as e:
        logger.exception(f"Erro no loop principal: {e}")
    finally:
        await finalizar_bot()

async def finalizar_bot():
    """Finaliza o bot e limpa recursos"""
    global app, scheduler
    
    logger.info("Finalizando bot...")
    
    if scheduler:
        scheduler.shutdown(wait=True)
        logger.info("Scheduler finalizado")
    
    if app:
        await app.stop()
        await app.shutdown()
        logger.info("Bot finalizado")

# ==========================
# MAIN
# ==========================
async def main():
    try:
        await inicializar_bot()
        await manter_bot_ativo()
    except Exception as e:
        logger.exception(f"Erro no main: {e}")
    finally:
        await finalizar_bot()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot interrompido pelo usuário")
    except Exception as e:
        logger.exception(f"Erro fatal: {e}")